package Q15;

public interface MathematicsInterface
{
	public int addition(int a, int b);
	public int subtraction(int a, int b);
	public int multiplication(int a, int b);
	public double division(int a, int b);
}

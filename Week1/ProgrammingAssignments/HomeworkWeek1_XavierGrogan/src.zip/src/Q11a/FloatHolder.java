package Q11a;

public class FloatHolder
{
	private static float first = 1.1f;
	private static float second = 2.2f;
	
	public static float getFirst()
	{
		return first;
	}
	public static float getSecond()
	{
		return second;
	}
}

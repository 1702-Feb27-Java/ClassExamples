package Q11;

public class Main
{
	public static void main(String[] args)
	{
		//fetches the first and second float from the other package
		System.out.println("First Digit: " + Q11a.FloatHolder.getFirst());
		System.out.println("Second Digit: " + Q11a.FloatHolder.getSecond());
	}
}

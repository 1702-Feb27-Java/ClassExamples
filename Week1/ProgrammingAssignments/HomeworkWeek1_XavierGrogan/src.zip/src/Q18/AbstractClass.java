package Q18;

abstract public class AbstractClass
{
	abstract public Boolean isThereUpper(String str);
	abstract public String allUpper(String str);
	abstract public int stringToInt(String str);
}

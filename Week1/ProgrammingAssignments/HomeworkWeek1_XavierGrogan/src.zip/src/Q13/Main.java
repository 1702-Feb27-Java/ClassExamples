package Q13;

public class Main
{
	//This just prints a triangle to the console
	public static void main(String[] args)
	{
		System.out.println(0);
		for(int i = 1; i < 5; i++)
		{
			for(int j = 0; j < i; j++)
			{
				System.out.print("01");
			}
			System.out.println();
		}
	}
}

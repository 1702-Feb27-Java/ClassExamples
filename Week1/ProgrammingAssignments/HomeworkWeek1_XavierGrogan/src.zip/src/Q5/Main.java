package Q5;
import java.util.*;

public class Main 
{
	//Takes in a string and an int, then makes the string a substring of the original without using the substring methods
	public static void main(String[] args) 
	{
		String str;
		int idx;
		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter a string: ");
		str = scan.nextLine();
		System.out.println("Please enter a number: ");
		idx = scan.nextInt();
		
		str = str.copyValueOf(str.toCharArray(), 0, idx-1);
		System.out.println(str);
	}
}
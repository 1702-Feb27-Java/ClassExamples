package Q16;

public class Main
{
	//takes the input string, saves it to a String variable, and calls the length of it
	public static void main(String[] args)
	{
		String input = args[0];
		System.out.println("There are " + input.length() + " characters in your string!");
	}
}

package com.revature.banking2.ui;

public interface Menu {

	void open();
	
}
